package cs1501.rec02.test;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;

import java.time.Duration;

import cs1501.rec02.BST;

public class TestBST {

    BST<Integer, Double> bst = null;
    final Integer [] KEYS = {1, 3, 4, 6, 7, 8, 10, 13, 14};
    final Double [] VALUES = {1.0, 3.0, 4.0, 6.0, 7.0, 8.0, 10.0, 13.0, 14.0};

    // Time limit per test
    public final int LIMIT = 10;

    @BeforeEach
    public void setup() {
        bst = new BST<Integer, Double>();
    }


    @Test
    public void testBSTPut() {
        assertTimeoutPreemptively(Duration.ofSeconds(LIMIT), () -> {
            assertTrue(bst.isEmpty(), "BST is not empty prior to putting key-value pairs.");

            // Preconditions and Execution Steps
            for (int i = 0; i < KEYS.length; i++) {
                bst.put(KEYS[i], VALUES[i]);
            }

            // Postconditions
            assertFalse(bst.isEmpty(), "BST is empty after putting all key-value pairs.");
            for (Integer key : KEYS) {
                assertTrue(bst.contains(key), "BST does not contain key " + key);
            }
        }, "Test did not complete within " + LIMIT + " seconds");
    }

    @Test
    public void testBSTDelete() {
        assertTimeoutPreemptively(Duration.ofSeconds(LIMIT), () -> {
            assertTrue(bst.isEmpty(), "BST is not empty prior to putting key-value pairs.");

            // Preconditions
            for (int i = 0; i < KEYS.length; i++) {
                bst.put(KEYS[i], VALUES[i]);
            }

            // Execution Steps
            bst.delete(1);
            bst.delete(10);

            // Postconditions
            assertFalse(bst.isEmpty(), "BST is empty after deleting two of the five keys");
            assertTrue(bst.contains(3), "BST does not contain the key 3");
            assertFalse(bst.contains(1), "BST contains the key 1 which should have been deleted");
            assertTrue(bst.contains(4), "BST does not contain the key 4");
            assertFalse(bst.contains(10), "BST contains the key 10 which should have been deleted");
            assertTrue(bst.contains(14), "BST does not contain the key 14");

        }, "Test did not complete within " + LIMIT + " seconds");
    }

    @Test
    public void testBSTRePut() {
        assertTimeoutPreemptively(Duration.ofSeconds(LIMIT), () -> {
            assertTrue(bst.isEmpty(), "BST is not empty prior to putting key-value pairs.");

            // Preconditions and Execution Steps
            for (int i = 0; i < KEYS.length; i++) {
                bst.put(KEYS[i], VALUES[i]);
            }

            // Execution Steps
            for (Integer key : KEYS) {
                bst.delete(key);
            }

            // Postconditions
            assertTrue(bst.isEmpty(), "BST is not empty after removing all key-value pairs.");

            bst.put(1, 1.0);

            assertFalse(bst.isEmpty(), "BST is empty after adding a new key 1");
            assertTrue(bst.contains(1), "BST does not contain the key 1");
        }, "Test did not complete within " + LIMIT + " seconds");
    }


}

