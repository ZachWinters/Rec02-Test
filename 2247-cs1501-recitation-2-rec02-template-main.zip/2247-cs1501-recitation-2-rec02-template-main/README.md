# CS 1501 Recitation 2: Binary Search Tree

## Introduction

In this recitation exercise, you will practice recursively traversing a tree
data structure by implementing a binary search tree. Recall that a binary search
tree has the rule applied that each node's left subtree contains keys less than
that node's key, and the right subtree contains keys greater than that node's
key. You will implement the `put` and `delete` methods of `BST` for inserting
key-value pairs and removing key-value pairs.

## Exercise

1) After your TA finishes their presentation on binary search trees, navigate to
your own Recitation 2 repository (named as `rec02-whoami`, where `whoami` is
your GitHub username).

   Launch a Codespace and review the structure of the repository.

   Navigate to the subdirectory `app/src/main/java/cs1501/rec02` and note the
   following provided Java files:

   - `Queue.java` is a generic queue data structure, implemented using a linked
     list.
   - `StdIn.java` reads in data of various types from standard input.
   - `StdOut.java` writes data of various types to standard output.
   - `BST.java` is a symbol table implemented with a binary search tree and
     contains all of the TODO tasks for this exercise.

   In addition to the main portion of the code, we have also provided a test
   class that can be found in the subdirectory
   `app/src/test/java/cs1501/rec02/test`. Note the following provided Java file:

   - `TestBST.java` contains example test cases for the BST class.

2) Run `./gradlew test` and note that the tests do not pass.

3) Read the contents of `./app/src/main/java/cs1501/rec02/BST.java`. In
particular, note the `TODO` comments for the `put` and `delete` methods.

4) At the first and second `TODO` comments, implement the `put` methods to allow
the BST to insert the specified key-value pair.

5) At the third and fourth `TODO` comments, implement the `delete` methods to
allow the BST to remove the specified key-value pair.

6) Run `./gradlew test` again and verify that the tests pass.

7) Once you’ve verified that your code is working correctly, use `git commit` to
commit your changes from the staging area.

8) Use `git push` to push your changes to your repository on GitHub. Use the
GitHub web interface to verify that your commit appears.

9) Use `git log` to observe the changes that have been made since this
repository was created.

10) To complete the exercise, submit your repository on Gradescope for
Recitation 2.

## Conclusion

In this exercise, you wrote implementation code for a BST data structure where a
node's left subtree contains keys less than that node's key, and the right
subtree contains keys greater than that node's key. You also practiced the
properties of recursion: (i) base case, (ii) recursive case, and (iii)
termination, by traversing the BST data structure.

